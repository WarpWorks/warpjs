const post = require('./post');

module.exports = {
    post
};
