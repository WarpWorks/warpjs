module.exports = (entity) => !entity.isAbstract;
