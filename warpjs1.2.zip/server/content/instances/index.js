const get = require('./get');
const post = require('./post');

module.exports = {
    get,
    post
};
