const routesInfo = require('./routes-info');

module.exports = {
    routesInfo
};
