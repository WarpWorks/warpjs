module.exports = {
    $active: {
        domain: null
    }
};
