const selectTargetEntity = require('./select-target-entity');

module.exports = () => {
    selectTargetEntity("aggregation");
};
