const updateNavBar = require('./update-nav-bar');

module.exports = {
    updateNavBar
};
