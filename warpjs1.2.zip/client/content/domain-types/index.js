const documentReady = require('./../document-ready');
const template = require('./template.hbs');

documentReady(jQuery, template);
