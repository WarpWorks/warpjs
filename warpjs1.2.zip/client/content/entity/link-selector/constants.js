module.exports = {
    SELECTION_MODAL_CLASS: 'link-selection-modal'
};
