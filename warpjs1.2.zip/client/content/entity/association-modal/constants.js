module.exports = {
    DIALOG_SELECTOR: '[data-warpjs-modal="target-association"]',
    CURRENT_ELEMENT_KEY: 'currentElement'
};
