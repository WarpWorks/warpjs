module.exports = {
    MODAL_CLASS: 'warpjs-wysiwyg-modal',
    CONTENT_CLASS: 'warpjs-wysiwyg-content'
};
