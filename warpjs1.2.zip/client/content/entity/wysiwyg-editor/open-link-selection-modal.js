const linkSelector = require('./../link-selector');

module.exports = ($, instanceDoc) => {
    linkSelector($, instanceDoc);
};
