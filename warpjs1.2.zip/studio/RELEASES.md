# Releases

## 1.0.0-rc12 - 2017-06-10

- Updated site logo.

## 1.0.0-rc11 - 2017-06-09

- Updated core for relationship description in association documents.

## 1.0.0-rc10 - 2017-06-07

- Updated warpjs@1.0.0-rc9

## 1.0.0-rc9 - 2017-06-06

- Updated warpjs@1.0.0-rc8

## 1.0.0-rc8 - 2017-06-06

- Updated core@1.0.0-rc3 and warpjs@1.0.0-rc7

## 1.0.0-rc7 - 2017-06-05

- Updated warpjs@1.0.0-rc6 and express-routes-info@0.1.7

## 1.0.0-rc6 - 2017-06-04

- Updated to core@1.0.0-rc2 and warpjs@1.0.0-rc4

## 1.0.0-rc5 - 2017-06-02

- Updated to warpjs@1.0.0-rc3

## 1.0.0-rc4 - 2017-06-01

- Updated to warpjs@1.0.0-rc2

## 1.0.0-rc3 - 2017-06-01

- Fixed link for the "Start Test Application"

## 1.0.0-rc2 - 2017-06-01

- Expose library version.

## 1.0.0-rc1 - 2017-05-31

- Embedded documents.

## 0.8.8 - 2017-05-10

- Fixed "Start Test Application" link.

## 0.8.7 - 2017-05-10

- Upgraded to @warp-works/core@0.8.7

## 0.8.6 - 2017-05-04

- Adjust to use WarpJS for authorization.

## 0.8.5 - 2017-04-24

- Updating to write into the `projectPath`.

## 0.8.4 - 2017-04-21

- Updating to WarpWorks/core 0.8.2

## 0.8.3 - 2017-04-21

- Adding password field.

## 0.8.2 - 2017-04-20

- Fixing PageView and TableView links.

## 0.8.1 - 2017-04-19

- Renaming HS -> W2
