# Contribution guide

## Before committing

Make sure to run the following before committing:

    npm run lint
    npm run coverage
